define(function() {
    return window.BJN;
});